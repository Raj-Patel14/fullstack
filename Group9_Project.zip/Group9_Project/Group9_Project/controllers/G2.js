const User = require("../models/user");

const getG2Page = async(req, res) => {
    const user = await User.findById(req.session.userId);
    res.render("G2_page", {
        user,
        errors: req.flash("validationErrors"),
    });
};

const enterG2Data = async(req, res) => {
    if (
        req.body.firstName === "" ||
        req.body.lastName === "" ||
        req.body.license_no === "" ||
        req.body.dob === "" ||
        req.body.age === "" ||
        req.body.make === "" ||
        req.body.model === "" ||
        req.body.year === "" ||
        req.body.platNo === ""
    ) {
        let errorMsg = "Please Enter Data in all the Fields";
        req.flash("validationErrors", errorMsg);
        return res.redirect("/G2");
    }
    await User.findByIdAndUpdate(req.params.id, {
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            license_no: req.body.license_no,
            dob: new Date(req.body.dob),
            age: req.body.age,
            carDetails: {
                make: req.body.make,
                model: req.body.model,
                year: req.body.year,
                platNo: req.body.platNo,
            },
        })
        .then(() => {
            res.redirect("/");
        })
        .catch((err) => {
            console.log(err);
        });
};

module.exports = {
    getG2Page,
    enterG2Data,
};
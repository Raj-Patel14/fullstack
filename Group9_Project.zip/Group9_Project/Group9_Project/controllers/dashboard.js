const getDashboardPage = (req, res) => {
  res.render("dashboard");
  console.log(req.session.userId);
};

module.exports = getDashboardPage;

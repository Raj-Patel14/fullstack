const bcrypt = require('bcryptjs');
const User = require("../models/user");

const getLoginPage = (req, res) => {
    res.render("login", {
        errors: req.flash("validationErrors"),
    });
};

const loginUser = async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username: username });

        if (user) {
            const same = await bcrypt.compare(password, user.password);

            if (same) {
                // if passwords match
                // store user session
                req.session.userId = user._id;
                // Setting global variable to check driver or not
                userType = user.userType;

                // Redirect to homepage if not a driver
                if (userType !== "Driver") {
                    res.redirect("/");
                    return;
                }

                if (user.license_no === "default") {
                    res.redirect(`/G2`);
                } else {
                    res.redirect("/");
                }
            } else {
                let errMsg = "Username or Password is wrong!";
                req.flash("validationErrors", errMsg);
                res.redirect("/login");
            }
        } else {
            let errMsg = `User does not exist! Please Register By clicking the link below!`;
            req.flash("validationErrors", errMsg);
            res.redirect("/login");
        }
    } catch (error) {
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
};

module.exports = {
    getLoginPage,
    loginUser,
};

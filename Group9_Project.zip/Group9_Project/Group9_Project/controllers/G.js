const User = require("../models/user");

const getUser = async(req, res) => {
    let userFound = true;
    let getUserData = "";

    if (req.session.userId) {
        getUserData = await User.findById(req.session.userId);
    }

    if (getUserData.license_no === "default") {
        userFound = false;
        res.render("G_page", { getUserData: "", userFound });
        return;
    }
    res.render("G_page", { getUserData, userFound });
};

const updateCarDetails = async(req, res) => {
    await User.findByIdAndUpdate(req.params.id, {
        carDetails: {
            make: req.body.make,
            model: req.body.model,
            year: req.body.year,
            platNo: req.body.platNo,
        },
    });
    res.redirect("/");
};

module.exports = {
    getUser,
    updateCarDetails,
};
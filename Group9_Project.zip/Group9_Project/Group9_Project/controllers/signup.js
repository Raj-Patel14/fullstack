const User = require("../models/user");

const getSignUpPage = (req, res) => {
  res.render("signup", {
    errors: req.flash("validationErrors"),
  });
};

const newUserSignUp = async (req, res) => {
  try {
    if (req.body.password !== req.body.confirm_password) {
      let errorMsg = "Passwords do not match!";
      req.flash("validationErrors", errorMsg);
      return res.redirect("/signup");
    }

    const user = await User.create(req.body);
    console.log(user);
    res.redirect("/login");
  } catch (err) {
    console.error(err);
    const validationErrors = Object.keys(err.errors).map(
      (key) => err.errors[key].message
    );
    console.log(validationErrors);
    req.flash("validationErrors", validationErrors);
    res.redirect("/signup");
  }
};

module.exports = {
  getSignUpPage,
  newUserSignUp,
};

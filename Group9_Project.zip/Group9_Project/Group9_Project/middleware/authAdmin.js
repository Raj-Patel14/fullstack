const DrivePost = require("../models/user");
module.exports = async(req, res, next) => {

    const user = await DrivePost.findById(req.session.userId);
    console.log(user);
    if (user.userType == "Admin") {
        next()
    } else {
        return res.redirect("/")
    }

};
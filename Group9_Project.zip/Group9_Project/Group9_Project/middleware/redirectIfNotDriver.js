const redirectIfNotDriver = (req, res, next) => {
  if (userType !== "Driver") {
    res.redirect("/");
  } else {
    console.log("driver");
  }
  next();
  return;
};

module.exports = redirectIfNotDriver;

const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const bcrypt = require("bcryptjs");
const uniqueValidator = require("mongoose-unique-validator");

const UserSchema = new Schema({
    username: {
        type: String,
        required: [true, "Please provide username"],
        unique: true,
    },
    password: {
        type: String,
        required: [true, "Please provide password"],
    },
    userType: {
        type: String,
        required: true,
    },
    firstName: {
        type: String,
        default: "default",
    },
    lastName: {
        type: String,
        default: "default",
    },
    dob: {
        type: Date,
        default: null,
    },
    age: {
        type: Number,
        default: 0,
    },
    license_no: {
        type: String,
        default: "default",
    },
    appointment: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'apdate'
    },
    carDetails: {
        make: {
            type: String,
            default: "default",
        },
        model: {
            type: String,
            default: "default",
        },
        year: {
            type: Number,
            default: 0,
        },
        platNo: {
            type: String,
            default: "default",
        },
    },
    // New Fields
    testType: {
        type: String,
        default: null,
    },
    comment: {
        type: String,
        default: null,
    },
    passFail: {
        type: Boolean,
        default: null,
    },
});

UserSchema.plugin(uniqueValidator);

UserSchema.pre("findOneAndUpdate", function(next) {
    const user = this;
    if (user._update.license_no) {
        bcrypt.hash(user._update.license_no, 10, (error, hash) => {
            user._update.license_no = hash;
            next();
        });
    } else {
        next();
    }
});

UserSchema.pre("save", function(next) {
    const user = this;
    bcrypt.hash(user.password, 10, (error, hash) => {
        user.password = hash;
        next();
    });
});

const User = mongoose.model("User", UserSchema);
module.exports = User;

const mongoose = require("mongoose");
const Schema = mongoose.Schema;


const ApDateSchema = new Schema({
    date: Date,
    slot: {
        type: String,
        default: ""
    },
    isAvail: Boolean
});

const ApDate = mongoose.model("ApDate", ApDateSchema);
module.exports = ApDate;